# DiamondWeb
Welcome to Diamond Web's Page on GitHub!
https://mrdiamond123.github.io/DiamondWeb/
Don't Be Mean About Sloppy Code!
